const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const MAX_MESSAGE_LENGTH = 320;
const MAX_QUEUE_LENGTH = 20;
const DUPLICATE_WINDOW_MS = Number(process.env.ICART_VOICE_DEBOUNCE_MS) || 1200;

const firstExisting = (candidates) => candidates.find((candidate) => candidate && fs.existsSync(candidate)) || null;

const piperExecutable = firstExisting([
  process.env.ICART_PIPER_EXECUTABLE,
  '/usr/local/bin/piper',
  '/usr/bin/piper',
]);
const piperModel = firstExisting([
  process.env.ICART_PIPER_MODEL,
  path.join(__dirname, '..', '..', 'voice', 'en_US-lessac-medium.onnx'),
  '/home/icart/icart/voice/en_US-lessac-medium.onnx',
]);
const piperModelConfig = piperModel && fs.existsSync(`${piperModel}.json`) ? `${piperModel}.json` : null;
const audioPlayer = firstExisting([
  process.env.ICART_AUDIO_PLAYER,
  '/usr/bin/aplay',
  '/bin/aplay',
]);
const audioDevice = String(process.env.ICART_AUDIO_DEVICE || '').trim();
const espeakExecutable = firstExisting([
  process.env.ICART_ESPEAK_EXECUTABLE,
  '/usr/bin/espeak-ng',
  '/bin/espeak-ng',
  '/usr/bin/espeak',
]);
const windowsSpeechExecutable = process.platform === 'win32' ? firstExisting([
  process.env.ICART_POWERSHELL_EXECUTABLE,
  path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe'),
]) : null;

const configuredProvider = String(process.env.ICART_TTS_PROVIDER || 'auto').toLowerCase();
const enabled = String(process.env.ICART_VOICE_ENABLED || 'true').toLowerCase() !== 'false';
const configuredPiperNice = Number.parseInt(process.env.ICART_PIPER_NICE || '15', 10);
const piperNice = Number.isInteger(configuredPiperNice)
  ? Math.max(-20, Math.min(19, configuredPiperNice))
  : 15;
const configuredSapiRate = Number.parseInt(process.env.ICART_SAPI_RATE || '0', 10);
const sapiRate = Number.isInteger(configuredSapiRate)
  ? Math.max(-10, Math.min(10, configuredSapiRate))
  : 0;
const configuredSapiVolume = Number.parseInt(process.env.ICART_SAPI_VOLUME || '100', 10);
const sapiVolume = Number.isInteger(configuredSapiVolume)
  ? Math.max(0, Math.min(100, configuredSapiVolume))
  : 100;
const sapiOutput = String(process.env.ICART_SAPI_OUTPUT || 'Speakers').trim();

const resolveProvider = () => {
  if (!enabled) return null;
  if ((configuredProvider === 'auto' || configuredProvider === 'piper')
      && piperExecutable && piperModel && piperModelConfig && audioPlayer) return 'piper';
  if ((configuredProvider === 'auto' || configuredProvider === 'sapi')
      && windowsSpeechExecutable) return 'sapi';
  if ((configuredProvider === 'auto' || configuredProvider === 'espeak') && espeakExecutable) return 'espeak';
  return null;
};

let queue = [];
let speaking = false;
let lastMessage = '';
let lastQueuedAt = 0;
let lastSpokenAt = null;
let lastError = null;

const runProcess = (executable, args, input, onDone, options = {}) => {
  let finished = false;
  const finish = (error) => {
    if (finished) return;
    finished = true;
    onDone(error);
  };

  const child = spawn(executable, args, {
    stdio: [input === undefined ? 'ignore' : 'pipe', 'ignore', 'pipe'],
    env: options.env || process.env,
  });
  if (Number.isInteger(options.nice) && child.pid) {
    try {
      os.setPriority(child.pid, options.nice);
    } catch (error) {
      console.warn(`[Voice] Unable to set process priority: ${error.message}`);
    }
  }
  let stderr = '';
  child.stderr?.on('data', (chunk) => { stderr = `${stderr}${chunk}`.slice(-1000); });
  child.once('error', finish);
  child.once('close', (code) => finish(code === 0 ? null : new Error(stderr.trim() || `Voice process exited with code ${code}`)));
  if (input !== undefined) child.stdin.end(input);
};

const speakWithEspeak = (message, done) => {
  const voice = process.env.ICART_ESPEAK_VOICE || 'en-us+f3';
  const rate = process.env.ICART_TTS_RATE || '150';
  const volume = process.env.ICART_TTS_VOLUME || '180';
  runProcess(espeakExecutable, ['-v', voice, '-s', rate, '-a', volume, message], undefined, done);
};

const speakWithPiper = (message, done) => {
  const wavPath = path.join(os.tmpdir(), `icart-voice-${process.pid}-${Date.now()}.wav`);
  const cleanup = () => fs.unlink(wavPath, () => {});

  runProcess(piperExecutable, ['--model', piperModel, '--output_file', wavPath], `${message}\n`, (piperError) => {
    if (piperError) {
      cleanup();
      done(piperError);
      return;
    }
    const playerArgs = ['-q'];
    if (audioDevice) playerArgs.push('-D', audioDevice);
    playerArgs.push(wavPath);
    runProcess(audioPlayer, playerArgs, undefined, (playerError) => {
      cleanup();
      done(playerError);
    });
  }, { nice: piperNice });
};

const speakWithWindowsSapi = (message, done) => {
  // The message is sent through stdin, not embedded in the command, so cart
  // and product text cannot be interpreted as PowerShell code.
  const script = [
    "$ErrorActionPreference = 'Stop'",
    '$message = [Console]::In.ReadToEnd()',
    "$wavPath = [IO.Path]::Combine([IO.Path]::GetTempPath(), ('icart-voice-' + [Guid]::NewGuid().ToString('N') + '.wav'))",
    'try { Add-Type -AssemblyName System.Speech; $voice = New-Object System.Speech.Synthesis.SpeechSynthesizer',
    `$voice.Rate = ${sapiRate}`,
    `$voice.Volume = ${sapiVolume}`,
    "if ($env:ICART_SAPI_VOICE) { $match = @($voice.GetInstalledVoices() | Where-Object { $_.VoiceInfo.Name -like ('*' + $env:ICART_SAPI_VOICE + '*') })[0]; if ($match) { $voice.SelectVoice($match.VoiceInfo.Name) } }",
    '$voice.SetOutputToWaveFile($wavPath)',
    '$voice.Speak($message)',
    '$voice.Dispose()',
    '$player = New-Object System.Media.SoundPlayer $wavPath',
    '$player.PlaySync()',
    '$player.Dispose() } finally { if ($voice) { $voice.Dispose() }; Remove-Item -LiteralPath $wavPath -Force -ErrorAction SilentlyContinue }',
  ].join('; ');
  runProcess(
    windowsSpeechExecutable,
    ['-NoProfile', '-NonInteractive', '-Command', script],
    message,
    done,
    { env: { ...process.env, ICART_SAPI_OUTPUT: sapiOutput } },
  );
};

const processQueue = () => {
  if (speaking || queue.length === 0) return;
  const provider = resolveProvider();
  if (!provider) {
    queue = [];
    return;
  }

  speaking = true;
  const message = queue.shift();
  const done = (error) => {
    if (error) {
      lastError = error.message;
      console.error(`[Voice] ${provider} failed: ${error.message}`);
    } else {
      lastError = null;
      lastSpokenAt = new Date().toISOString();
    }
    speaking = false;
    processQueue();
  };

  if (provider === 'piper') speakWithPiper(message, done);
  else if (provider === 'sapi') speakWithWindowsSapi(message, done);
  else speakWithEspeak(message, done);
};

const getVoiceStatus = () => {
  const provider = resolveProvider();
  return {
    available: Boolean(provider),
    provider,
    naturalVoice: provider === 'piper',
    audioDevice: provider === 'sapi' ? sapiOutput : audioDevice || 'default',
    speaking,
    queuedMessages: queue.length,
    lastSpokenAt,
    lastError,
    message: provider === 'piper'
      ? 'Piper neural voice is ready.'
      : provider === 'sapi'
        ? 'Windows Speech voice is ready.'
      : provider === 'espeak'
        ? 'Offline eSpeak voice is ready. Add a Piper model for a more natural voice.'
        : 'No local speech engine is available; the kiosk will use browser speech instead.',
  };
};

const queueSpeech = (rawMessage) => {
  const message = String(rawMessage || '').replace(/\s+/g, ' ').trim().slice(0, MAX_MESSAGE_LENGTH);
  if (!message) return { accepted: false, reason: 'empty' };
  if (!resolveProvider()) return { accepted: false, reason: 'unavailable' };

  const now = Date.now();
  if (message === lastMessage && now - lastQueuedAt < DUPLICATE_WINDOW_MS) {
    return { accepted: true, duplicate: true };
  }
  if (queue.length >= MAX_QUEUE_LENGTH) queue.shift();
  queue.push(message);
  lastMessage = message;
  lastQueuedAt = now;
  processQueue();
  return { accepted: true, duplicate: false };
};

module.exports = { getVoiceStatus, queueSpeech, MAX_MESSAGE_LENGTH };
